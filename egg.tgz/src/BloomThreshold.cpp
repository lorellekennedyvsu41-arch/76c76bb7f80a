// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Extract bloom highlights"); }
int main(){
  announce();
  return lionss_run_workload("BloomThreshold");
}
