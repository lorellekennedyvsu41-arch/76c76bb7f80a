// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Analyze demand\n", stdout);
  return lionss_run_workload("HaskellStrictness");
}
