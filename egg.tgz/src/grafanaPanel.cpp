// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Render time-series panel"); }
int main(){
  announce();
  return lionss_run_workload("grafanaPanel");
}
