// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Pack lightmap UV2"); }
int main(){
  announce();
  return lionss_run_workload("lightmap_uv2");
}
