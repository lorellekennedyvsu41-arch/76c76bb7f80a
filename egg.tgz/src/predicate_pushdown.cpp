// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Push predicates down"); }
int main(){
  announce();
  return lionss_run_workload("predicate_pushdown");
}
